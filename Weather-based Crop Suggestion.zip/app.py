from flask import Flask, render_template, request
import pickle
import numpy as np
import os

app = Flask(__name__)

# Load model
if os.path.exists("model.pkl"):
    print("📦 model.pkl found!")
    with open("model.pkl", "rb") as f:
        model = pickle.load(f)
else:
    print("❌ model.pkl NOT found!")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    features = [float(x) for x in request.form.values()]
    prediction = model.predict([np.array(features)])
    return render_template('index.html', prediction_text=f"Recommended Crop: {prediction[0]}")

if __name__ == '__main__':
    app.run(debug=True)
